import cv2
import rospy
import time
from threading import Thread
from .camera import Camera
import numpy as np
from std_msgs.msg import String


class Shoot_Detect():
    def __init__(self, shoot_topic) -> None:
        self.result = 0
        self.shoot_pub = rospy.Publisher(shoot_topic, String, queue_size=10)
        self.runing = False

    def color(self, frame, up, low, width=100):  # 获取中心点图像颜色置信度
        img = frame.crop_center(width, width)
        if not isinstance(up, np.ndarray):
            up = np.array(up)
        if not isinstance(low, np.ndarray):
            low = np.array(low)
        mask = cv2.inRange(img, low, up)
        white_pixels = cv2.countNonZero(mask)
        cv2.imshow("test", mask)
        return white_pixels / (width * width)

    def position(self, frame, num, x, y, theta):  # 识别位置是否满足发射要求
        if not self.runing:
            if (frame.x - theta < x < frame.x + theta and frame.y - theta < y < frame.y + theta) or num > 0.9:
                self.shoot()
            else:
                self.stop()

    def shoot(self):  # 开炮
        msg = String()
        self.runing = True
        for i in range(3):
            msg.data = '1'
            self.shoot_pub.publish(msg)
            time.sleep(0.05)

    def stop(self):  # 停止
        msg = String()
        self.runing = True
        for i in range(3):
            msg.data = '0'
            self.shoot_pub.publish(msg)
            time.sleep(0.05)


if __name__ == "__main__":
    cam = Camera(0)
    cam.open()
    detect = Shoot_Detect()
    while 1:
        frame = cam.get()
        if frame:
            score = detect.color(frame, [130, 255, 255], [110, 50, 50])
            print("{:.3f}".format(score))
            if cv2.waitKey(10) == ord('q'):
                break
    cv2.destroyAllWindows()
    cam.close()